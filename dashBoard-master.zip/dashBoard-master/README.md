# Data Dashboard

Creación del producto final Data Dashboard para la empresa Laboratoria.

Deacuerdo a los requerimientos de nuestro cliente:

  - Información general de cada sede y por generación.
  - Informacion en especifico de cada Alumna.

sketch ![](assets/images/sketch.png)

1. Primer página login.html link directo a la página overview.html.

2. En la segunda página overview.html se encuentra la información general de por sede y generación. A su vez un boton que te lleva a la tercer página index.html y un boton salir.

3. la tercer página index.html te muestra las opciones de sede y generacion para encontrar la información en especifico de cada alumna.


#Conclusiones
